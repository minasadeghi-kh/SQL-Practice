-- Section1
SELECT name
FROM athletes
WHERE nationality = 'Islamic Republic of Iran'
ORDER BY name ASC;

-- Section2
SELECT discipline, nationality, COUNT(*) as count
FROM athletes
GROUP BY discipline, nationality
ORDER BY count DESC;

-- Section3
SELECT nationality, COUNT(*) as count
FROM athletes
GROUP BY nationality
ORDER BY count DESC;


    
